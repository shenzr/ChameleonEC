#ifndef _LINES_FNWORKER_HH_
#define _LINES_FNWORKER_HH_

#define BLOCKPAUSE 1
#define ENABLE_PAUSE 1
#define DISABLE_PAUSE 0

#include <string>
#include <cassert>
#include "DRWorker.hh"
#include "BUTTERFLY64Util.hh"

class LinesFullNodeWorker : public DRWorker {
    size_t _sendOnlyThreadNum;
    size_t _receiveAndSendThreadNum;
    thread _sendOnlyThrd;
    thread _receiveAndSendThrd;

    bool _sendWorkerFree;
    mutex _sendWorkerMtx;
    condition_variable _sendWorkerCv;

    bool _multiplyFree;
    mutex _multiplyMtx;
    condition_variable _multiplyCv;

    BUTTERFLYUtil* _butterflyUtil;
    int _decMatButterFly[6][20 * 8];
    int _lostBlkIdxBF;
    
    // for pausing task
    int _receivePauseFlag, _sendPauseFlag;

    map<string, int> isTaskCached;
    map<string, pair<char*, int> > blk2Cmds;
    vector<string> pausedBlks;
    map<string, vector<string> > pausedTaskCheckCmd;
    redisContext* _coordinatorCtx;
    string localIPStr;
    int _pause_mode;


    void readWorker(int&, variablesForTran& var, string, string, int, int, int, int);
    void pullWorker(int&, variablesForTran& var, redisContext*, unsigned int, int, int, string, int butterfly_id_in_stripe = 0, int butterfly_lost_blk_id_in_stripe = 0);
    void sendWorker(int&, variablesForTran& var, redisContext* rc, unsigned int senderIp, string lostBlkName, int, int);

    public: 
        LinesFullNodeWorker(Config* conf);
        void doProcess();
        void sendOnly(redisContext* selfCtx);
        void receiveAndSend(redisContext* selfCtx);
};

#endif  //_LINES_FNWORKER_HH_

